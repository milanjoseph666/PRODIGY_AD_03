# Stopwatch App (Android using Kivy)

## Description
A basic stopwatch application that shows:
- Minutes
- Seconds
- Milliseconds

Users can:
- Start the stopwatch
- Pause it
- Reset the timer

## How to Run
1. Install Kivy: `pip install kivy`
2. Run the app using:
   python main.py

## To Build as APK (Optional)
Use Buildozer:
1. Install buildozer: `pip install buildozer`
2. Initialize: `buildozer init`
3. Build: `buildozer -v android debug`

## Author
Prodigy Infotech Task-03 Submission
